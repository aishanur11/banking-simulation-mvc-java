package Model;

/**
 * This class represents a bank that tracks the player's balance. It allows placing bets,
 * adding winnings, and checking for bankruptcy.
 *
 * @author aishanur
 * @version Autumn 2024
 */
public class Bank {

    /** The current balance in the bank. */
    private double balance;

    /**
     * Constructs a new Bank instance with an initial balance.
     * @param initialBalance the initial balance of the bank.
     * @throws IllegalArgumentException if the initial balance is negative.
     */
    public Bank(double initialBalance) {
        if (initialBalance < 0) throw new IllegalArgumentException("Initial balance cannot be negative.");
        balance = initialBalance;
    }

    /**
     * Gets the current balance of the bank.
     * @return the current balance.
     */
    public double getBalance() {
        return balance;
    }

    /**
     * Places a bet by subtracting the bet amount from the current balance.
     * @param bet the amount to bet.
     * @throws IllegalArgumentException if the bet is less than or equal to zero or greater than the current balance.
     */
    public void placeBet(double bet) {
        if (bet <= 0 || bet > balance) throw new IllegalArgumentException("Invalid bet.");
        balance -= bet;
    }

    /**
     * Adds winnings to the current balance.
     * @param amount the amount of winnings to add.
     * @throws IllegalArgumentException if the winnings amount is negative.
     */
    public void addWinnings(double amount) {
        if (amount < 0) throw new IllegalArgumentException("Winnings cannot be negative.");
        balance += amount;
    }

    /**
     * Checks if the bank is bankrupt (i.e., if the balance is zero).
     * @return true if the balance is zero, indicating bankruptcy; false otherwise.
     */
    public boolean isBankrupt() {
        return balance == 0;
    }
}
