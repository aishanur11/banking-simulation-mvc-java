package Tests;

import Model.GameModel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the GameModel class.
 * This class tests the functionality of the GameModel
 * including game state management, dice rolls, and game resets.
 *
 * @author aishanur
 * @version Autumn 2024
 */
class GameModelTest {

    /** Instance of the GameModel class to be tested. */
    private GameModel gameModel;

    /**
     * Sets up the test environment by initializing the gameModel instance before each test.
     */
    @BeforeEach
    void setUp() {
        gameModel = new GameModel();
    }

    /**
     * Tests the initial state of the game before it is started.
     * Verifies that the game is not started, no point is established, and dice values are zero.
     */
    @Test
    void testInitialGameState() {
        assertFalse(gameModel.isGameStarted(), "Game should not be started initially.");
        assertFalse(gameModel.isPointEstablished(), "No point should be established initially.");
        assertEquals(0, gameModel.getDice1(), "Dice 1 should be 0 initially.");
        assertEquals(0, gameModel.getDice2(), "Dice 2 should be 0 initially.");
        assertEquals(0, gameModel.getTotal(), "Total value of dice should be 0 initially.");
        assertEquals(0, gameModel.getPoint(), "Point should be 0 initially.");
    }

    /**
     * Tests the behavior of starting the game.
     * Verifies that the game state changes to 'started' after calling startGame().
     */
    @Test
    void testStartGame() {
        gameModel.startGame();
        assertTrue(gameModel.isGameStarted(), "Game should be started after calling startGame.");
    }

    /**
     * Tests the rollDice method for possible outcomes.
     * Verifies that the result of rolling the dice can be one of the valid outcomes.
     */
    @Test
    void testRollDice_WinCondition() {
        // Mock dice rolls for win
        String result = gameModel.rollDice();
        assertTrue(result.equals("WIN") || result.equals("LOSE") || result.equals("POINT") || result.equals("ROLL_AGAIN"),
                "Dice roll result should be one of the following: WIN, LOSE, POINT, or ROLL_AGAIN.");
    }

    /**
     * Tests the resetGame method.
     * Verifies that the game state is reset to its initial state after calling resetGame().
     */
    @Test
    void testResetGame() {
        gameModel.startGame();
        gameModel.resetGame();
        assertFalse(gameModel.isGameStarted(), "Game should not be started after reset.");
        assertFalse(gameModel.isPointEstablished(), "Point should not be established after reset.");
        assertEquals(0, gameModel.getDice1(), "Dice 1 should be 0 after reset.");
        assertEquals(0, gameModel.getDice2(), "Dice 2 should be 0 after reset.");
        assertEquals(0, gameModel.getTotal(), "Total value of dice should be 0 after reset.");
        assertEquals(0, gameModel.getPoint(), "Point should be 0 after reset.");
    }
}
