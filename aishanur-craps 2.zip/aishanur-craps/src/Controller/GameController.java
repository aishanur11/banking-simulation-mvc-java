package Controller;

import Model.GameModel;
import View.GameView;

import javax.swing.*;

/**
 * Controller class that manages the interaction between the model and view for the Craps game.
 * It listens to user actions, such as starting the game, rolling dice,
 * resetting the game, and displaying game rules or information.
 * @author aishanur
 * @version Autumn 2024
 */
public class GameController {
    /**
     * The game model that contains the logic of the game.
     */
    private final GameModel model;

    /**
     * The game view that displays the graphical user interface for the game.
     */
    private final GameView view;

    /**
     * The current bank balance of the player.
     */
    private double currentBankBalance;

    /**
     * Constructs a GameController instance, linking the model and view, and adds action listeners to the view components.
     *
     * @param model The game model.
     * @param view The game view.
     */
    public GameController(GameModel model, GameView view) {
        this.model = model;
        this.view = view;

        // Adding action listeners for menu items and buttons
        view.getStartMenuItem().addActionListener(_ -> startGame());
        view.getRollButton().addActionListener(_ -> rollDice());
        view.getPlayAgainButton().addActionListener(_ -> playAgain());
        view.getResetMenuItem().addActionListener(_ -> resetGame());
        view.getExitMenuItem().addActionListener(_ -> System.exit(0));
        view.getRulesMenuItem().addActionListener(_ -> showRules());
        view.getAboutMenuItem().addActionListener(_ -> showAbout());
    }

    /**
     * Starts a new game by prompting the user to input their initial bank balance.
     * If the input is valid, the game starts with that balance.
     */
    private void startGame() {
        String input = JOptionPane.showInputDialog(view, "Enter initial bank balance:");
        try {
            // Store the initial bank balance
            double initialBankBalance = Double.parseDouble(input); // Save the initial bank balance
            if (initialBankBalance < 0) {
                throw new IllegalArgumentException("Bank balance cannot be negative.");
            }
            currentBankBalance = initialBankBalance; // Set current balance
            view.getBankAccountLabel().setText("Bank Balance: $" + currentBankBalance);
            model.startGame();
            view.getRollButton().setEnabled(true);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Invalid input. Please try again.");
        }
    }

    /**
     * Rolls the dice and updates the game state based on the result.
     * The player can place a bet, and the result of the roll determines whether they win, lose, or set a point.
     */
    private void rollDice() {
        String betInput = JOptionPane.showInputDialog(view, "Enter your bet amount:");
        try {
            double betAmount = Double.parseDouble(betInput);

            if (betAmount <= 0 || betAmount > currentBankBalance) {
                JOptionPane.showMessageDialog(view, "Invalid bet amount. Please try again.");
                return;
            }

            String result = model.rollDice();
            int die1 = model.getDice1();  // Get the value of die 1
            int die2 = model.getDice2();  // Get the value of die 2

            // Update the labels for the total, point, and game message
            view.getDice1Label().setText("Die 1: " + die1);
            view.getDice2Label().setText("Die 2: " + die2);
            view.getTotalLabel().setText("Total: " + model.getTotal());

            // Handle the result (WIN, LOSE, POINT, etc.)
            switch (result) {
                case "WIN":
                    currentBankBalance += betAmount * 2;
                    model.incrementPlayerWins();
                    view.getPlayerWinsLabel().setText("Player Wins: " + model.getPlayerWins());
                    view.getMessageLabel().setText("You Win!");
                    view.getRollButton().setEnabled(false); // Disable Roll Dice
                    view.getPlayAgainButton().setEnabled(true); // Enable Play Again
                    break;
                case "LOSE":
                    currentBankBalance -= betAmount;
                    model.incrementHouseWins();
                    view.getHouseWinsLabel().setText("House Wins: " + model.getHouseWins());
                    view.getMessageLabel().setText("You Lose!");
                    view.getRollButton().setEnabled(false); // Disable Roll Dice
                    view.getPlayAgainButton().setEnabled(true); // Enable Play Again
                    break;
                case "POINT":
                    view.getMessageLabel().setText("Point is set: " + model.getPoint());
                    break;
                default:
                    view.getMessageLabel().setText("Roll Again.");
            }

            view.getBankAccountLabel().setText("Bank Balance: $" + currentBankBalance);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Invalid bet. Please enter a valid number.");
        }
    }

    /**
     * Resets the game state, including the model and view components, and sets the player's bank balance to zero.
     */
    private void resetGame() {
        model.resetGame();
        currentBankBalance = 0; // Set bank balance to zero on reset

        // Reset the labels to their initial state
        view.getDice1Label().setText("Die 1: ");
        view.getDice2Label().setText("Die 2: ");
        view.getTotalLabel().setText("Total: ");
        view.getPointLabel().setText("Point: ");
        view.getMessageLabel().setText("Game reset. Roll to play again.");

        view.getPlayerWinsLabel().setText("Player Wins: 0");
        view.getHouseWinsLabel().setText("House Wins: 0");

        view.getBankAccountLabel().setText("Bank Balance: $" + currentBankBalance);
        view.getRollButton().setEnabled(false);
        view.getPlayAgainButton().setEnabled(false);
    }

    /**
     * Displays the rules of the Craps game in a message dialog.
     */
    private void showRules() {
        String rules = """
        Rules of Craps:
        1. On the first roll (the 'Come Out' roll):
           - Rolling a 7 or 11 wins the game.
           - Rolling a 2, 3, or 12 loses the game.
           - Any other number becomes the 'Point'.
        2. If a Point is established:
           - You must roll the Point again before rolling a 7 to win.
           - Rolling a 7 before the Point loses the game.
        3. You can bet on each roll and the winnings are doubled if you win.
        """;
        JOptionPane.showMessageDialog(view, rules, "Game Rules", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Starts a new round of the game, resetting only the dice and point, but not the win counts.
     */
    private void playAgain() {
        // Only reset the dice and point, not the wins
        model.resetGameRound();  // Add a method to reset only the round state

        view.getDice1Label().setText("Die 1: ");
        view.getDice2Label().setText("Die 2: ");
        view.getTotalLabel().setText("Total: ");
        view.getPointLabel().setText("Point: ");
        view.getMessageLabel().setText("Roll to play again.");

        view.getRollButton().setEnabled(true);  // Enable Roll Dice button
        view.getPlayAgainButton().setEnabled(false); // Disable Play Again button
    }

    /**
     * Displays information about the game in a message dialog.
     */
    private void showAbout() {
        String about = """
        About This Game:
        - This is a simplified version of the classic dice game Craps.
        - Developed using Java Swing for GUI and MVC architecture.
        - Place bets, roll the dice, and test your luck!
        - Designed for educational purposes and entertainment.
        """;
        JOptionPane.showMessageDialog(view, about, "About Craps Game", JOptionPane.INFORMATION_MESSAGE);
    }
}
