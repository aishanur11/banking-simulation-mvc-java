import Controller.GameController;
import Model.GameModel;
import View.GameView;

import javax.swing.*;

/**
 * The main entry point for the Craps game application.
 * Initializes the model, view, and controller, and makes the view visible.
 *
 * @author Aisha Nur
 * @version Autumn 2024
 */

public class Main {

    public static void main() {
        // Create the model, view, and controller
        GameModel model = new GameModel();
        GameView view = new GameView();
        GameController controller = new GameController(model, view);

        // Make the view visible
        SwingUtilities.invokeLater(() -> view.setVisible(true));
    }
}
