package Tests;

import Model.Bank;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Bank class.
 * This class tests the functionality of the Bank class
 * including balance management, placing bets,
 * adding winnings, and checking for bankruptcy.
 *
 * @author aishanur
 * @version Autumn 2024
 */
class BankTest {

    /** Instance of the Bank class to be tested. */
    private Bank bank;

    /**
     * Sets up the test environment by initializing the bank instance with an initial balance of 100.0 before each test.
     */
    @BeforeEach
    void setUp() {
        bank = new Bank(100.0);
    }

    /**
     * Tests the initial balance of the bank.
     * Verifies that the balance is correctly initialized to 100.0.
     */
    @Test
    void testInitialBalance() {
        assertEquals(100.0, bank.getBalance(), "Initial balance should be 100.0.");
    }

    /**
     * Tests placing a valid bet.
     * Verifies that the balance is updated correctly after placing a bet of 50.0.
     */
    @Test
    void testPlaceBet_ValidBet() {
        bank.placeBet(50.0);
        assertEquals(50.0, bank.getBalance(), "Balance should be reduced by the bet amount.");
    }

    /**
     * Tests placing an invalid bet.
     * Verifies that an IllegalArgumentException is thrown when trying to place a bet greater than the balance or a negative bet.
     */
    @Test
    void testPlaceBet_InvalidBet() {
        // Test bet greater than balance
        assertThrows(IllegalArgumentException.class, () -> bank.placeBet(150.0), "Placing a bet greater than balance should throw an exception.");

        // Test negative bet
        assertThrows(IllegalArgumentException.class, () -> bank.placeBet(-10.0), "Placing a negative bet should throw an exception.");
    }

    /**
     * Tests adding valid winnings to the bank.
     * Verifies that the balance is updated correctly after adding 50.0 in winnings.
     */
    @Test
    void testAddWinnings() {
        bank.addWinnings(50.0);
        assertEquals(150.0, bank.getBalance(), "Balance should be increased by the winnings amount.");
    }

    /**
     * Tests adding invalid winnings to the bank.
     * Verifies that an IllegalArgumentException is thrown when trying to add a negative amount.
     */
    @Test
    void testAddWinnings_InvalidAmount() {
        assertThrows(IllegalArgumentException.class, () -> bank.addWinnings(-10.0), "Adding negative winnings should throw an exception.");
    }

    /**
     * Tests the bankruptcy check of the bank.
     * Verifies that the bank is correctly identified as bankrupt when the balance reaches 0 after placing a bet.
     */
    @Test
    void testIsBankrupt() {
        assertFalse(bank.isBankrupt(), "Bank should not be bankrupt initially.");

        // Place a bet that empties the bank
        bank.placeBet(100.0);

        assertTrue(bank.isBankrupt(), "Bank should be bankrupt after placing a bet that reduces the balance to 0.");
    }
}
