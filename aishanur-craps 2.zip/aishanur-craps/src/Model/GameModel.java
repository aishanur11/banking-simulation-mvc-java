package Model;

import java.util.Random;

/**
 * This class represents the game logic for the Craps game.
 * It handles the rolling of dice,
 * tracking of player and house wins, and managing
 * the state of the game, including point establishment.
 *
 * @author aishanur
 * @version Autumn 2024
 */
public class GameModel {

    /** The value of the first die. */
    private int die1;

    /** The value of the second die. */
    private int die2;

    /** The total value of both dice. */
    private int total;

    /** The point value for the game, set if a point is established. */
    private int point;

    /** Flag indicating whether the game has started. */
    private boolean gameStarted;

    /** Flag indicating whether a point has been established in the game. */
    private boolean pointEstablished;

    /** A Random object used for rolling the dice. */
    private final Random random;

    /** The number of wins the player has achieved. */
    private int playerWins;

    /** The number of wins the house has achieved. */
    private int houseWins;

    /**
     * Constructs a new GameModel instance and initializes the game state.
     */
    public GameModel() {
        random = new Random();
        resetGame();
        playerWins = 0;
        houseWins = 0;
    }

    /**
     * Resets the game state, including dice values, total, point, and win counts.
     */
    public void resetGame() {
        die1 = die2 = total = point = 0;
        gameStarted = false;
        pointEstablished = false;
        playerWins = 0;  // Reset player wins
        houseWins = 0;   // Reset house wins
    }

    /**
     * Starts the game by setting the gameStarted flag to true.
     */
    public void startGame() {
        gameStarted = true;
    }

    /**
     * Returns whether the game has started.
     * @return true if the game has started, false otherwise.
     */
    public boolean isGameStarted() {
        return gameStarted;
    }

    /**
     * Returns whether a point has been established.
     * @return true if a point has been established, false otherwise.
     */
    public boolean isPointEstablished() {
        return pointEstablished;
    }

    /**
     * Gets the value of the first die.
     * @return the value of the first die.
     */
    public int getDice1() {
        return die1;
    }

    /**
     * Gets the value of the second die.
     * @return the value of the second die.
     */
    public int getDice2() {
        return die2;
    }

    /**
     * Gets the total value of the two dice.
     * @return the total of the two dice.
     */
    public int getTotal() {
        return total;
    }

    /**
     * Gets the point value, which is set when a point is established.
     * @return the point value.
     */
    public int getPoint() {
        return point;
    }

    /**
     * Increments the player's win count.
     */
    public void incrementPlayerWins() {
        playerWins++;
    }

    /**
     * Increments the house's win count.
     */
    public void incrementHouseWins() {
        houseWins++;
    }

    /**
     * Gets the total number of wins the player has achieved.
     * @return the player's win count.
     */
    public int getPlayerWins() {
        return playerWins;
    }

    /**
     * Gets the total number of wins the house has achieved.
     * @return the house's win count.
     */
    public int getHouseWins() {
        return houseWins;
    }

    /**
     * Rolls the dice and returns the result of the roll.
     * - "WIN" if the player wins on the first roll or after establishing a point.
     * - "LOSE" if the player loses on the first roll or after establishing a point.
     * - "POINT" if a point is established on the first roll.
     * - "ROLL_AGAIN" if the player needs to roll again.
     * @return the result of the roll as a string.
     */
    public String rollDice() {
        die1 = random.nextInt(6) + 1;
        die2 = random.nextInt(6) + 1;
        total = die1 + die2;

        if (!pointEstablished) {
            if (total == 7 || total == 11) return "WIN";
            else if (total == 2 || total == 3 || total == 12) return "LOSE";
            else {
                point = total;
                pointEstablished = true;
                return "POINT";
            }
        } else {
            if (total == point) return "WIN";
            if (total == 7) return "LOSE";
        }
        return "ROLL_AGAIN";
    }

    /**
     * Resets the round, including the dice, point, and flags, without resetting the win counts.
     */
    public void resetGameRound() {
        die1 = die2 = total = point = 0;
        pointEstablished = false;
        gameStarted = false;
    }
}
