package View;

import javax.swing.*;
import java.awt.*;

/**
 * The GameView class represents the graphical user interface (GUI) for the Craps game.
 * It provides the layout, controls, and display components for the game.
 *
 * @author aishanur
 * @version Autumn 2024
 */
public class GameView extends JFrame {

    /** Menu item to start the game. */
    private final JMenuItem startMenuItem;

    /** Menu item to reset the game. */
    private final JMenuItem resetMenuItem;

    /** Menu item to exit the game. */
    private final JMenuItem exitMenuItem;

    /** Menu item to view the rules of the game. */
    private final JMenuItem rulesMenuItem;

    /** Menu item to view information about the game. */
    private final JMenuItem aboutMenuItem;

    /** Button to roll the dice. */
    private final JButton rollButton;

    /** Button to play the game again. */
    private final JButton playAgainButton;

    /** Label to display the value of die 1. */
    private final JLabel dice1Label;

    /** Label to display the value of die 2. */
    private final JLabel dice2Label;

    /** Label to display the total value of both dice. */
    private final JLabel totalLabel;

    /** Label to display the current point in the game. */
    private final JLabel pointLabel;

    /** Label to display messages to the player. */
    private final JLabel messageLabel;

    /** Label to display the current bank balance. */
    private final JLabel bankAccountLabel;

    /** Label to display the number of player wins. */
    private final JLabel playerWinsLabel;

    /** Label to display the number of house wins. */
    private final JLabel houseWinsLabel;

    /**
     * Constructs the GameView and initializes the UI components.
     */
    public GameView() {
        setTitle("Craps Game");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Menu
        JMenuBar menuBar = new JMenuBar();
        JMenu gameMenu = new JMenu("Game");
        startMenuItem = new JMenuItem("Start");
        resetMenuItem = new JMenuItem("Reset");
        exitMenuItem = new JMenuItem("Exit");
        gameMenu.add(startMenuItem);
        gameMenu.add(resetMenuItem);
        gameMenu.addSeparator();
        gameMenu.add(exitMenuItem);

        JMenu helpMenu = new JMenu("Help");
        rulesMenuItem = new JMenuItem("Rules (Ctrl + R)");
        aboutMenuItem = new JMenuItem("About (Ctrl + A)");

        rulesMenuItem.setAccelerator(KeyStroke.getKeyStroke("ctrl R")); // Ctrl+R for Rules
        aboutMenuItem.setAccelerator(KeyStroke.getKeyStroke("ctrl A")); // Ctrl+A for About

        helpMenu.add(rulesMenuItem);
        helpMenu.add(aboutMenuItem);

        menuBar.add(gameMenu);
        menuBar.add(helpMenu);
        setJMenuBar(menuBar);

        // Controls
        JPanel controlPanel = new JPanel();
        rollButton = new JButton("Roll Dice");
        playAgainButton = new JButton("Play Again");
        rollButton.setEnabled(false);
        playAgainButton.setEnabled(false);
        controlPanel.add(rollButton);
        controlPanel.add(playAgainButton);

        // Display
        JPanel displayPanel = new JPanel(new GridLayout(3, 2));
        dice1Label = new JLabel("Die 1: ");
        dice2Label = new JLabel("Die 2: ");
        totalLabel = new JLabel("Total: ");
        pointLabel = new JLabel("Point: ");
        messageLabel = new JLabel("Welcome to Craps!");
        bankAccountLabel = new JLabel("Bank Balance: $0.00");

        displayPanel.add(dice1Label);
        displayPanel.add(dice2Label);
        displayPanel.add(totalLabel);
        displayPanel.add(pointLabel);
        displayPanel.add(messageLabel);
        displayPanel.add(bankAccountLabel);

        add(controlPanel, BorderLayout.SOUTH);
        add(displayPanel, BorderLayout.CENTER);

        playerWinsLabel = new JLabel("Player Wins: 0");
        houseWinsLabel = new JLabel("House Wins: 0");

        displayPanel.add(playerWinsLabel);
        displayPanel.add(houseWinsLabel);

        add(controlPanel, BorderLayout.SOUTH);
        add(displayPanel, BorderLayout.CENTER);
    }

    /**
     * Gets the start menu item.
     * @return the start menu item.
     */
    public JMenuItem getStartMenuItem() {
        return startMenuItem;
    }

    /**
     * Gets the reset menu item.
     * @return the reset menu item.
     */
    public JMenuItem getResetMenuItem() {
        return resetMenuItem;
    }

    /**
     * Gets the exit menu item.
     * @return the exit menu item.
     */
    public JMenuItem getExitMenuItem() {
        return exitMenuItem;
    }

    /**
     * Gets the rules menu item.
     * @return the rules menu item.
     */
    public JMenuItem getRulesMenuItem() {
        return rulesMenuItem;
    }

    /**
     * Gets the about menu item.
     * @return the about menu item.
     */
    public JMenuItem getAboutMenuItem() {
        return aboutMenuItem;
    }

    /**
     * Gets the roll dice button.
     * @return the roll dice button.
     */
    public JButton getRollButton() {
        return rollButton;
    }

    /**
     * Gets the play again button.
     * @return the play again button.
     */
    public JButton getPlayAgainButton() {
        return playAgainButton;
    }

    /**
     * Gets the label for die 1.
     * @return the die 1 label.
     */
    public JLabel getDice1Label() {
        return dice1Label;
    }

    /**
     * Gets the label for die 2.
     * @return the die 2 label.
     */
    public JLabel getDice2Label() {
        return dice2Label;
    }

    /**
     * Gets the label for the total value of both dice.
     * @return the total label.
     */
    public JLabel getTotalLabel() {
        return totalLabel;
    }

    /**
     * Gets the label for the current point.
     * @return the point label.
     */
    public JLabel getPointLabel() {
        return pointLabel;
    }

    /**
     * Gets the message label.
     * @return the message label.
     */
    public JLabel getMessageLabel() {
        return messageLabel;
    }

    /**
     * Gets the bank account label.
     * @return the bank account label.
     */
    public JLabel getBankAccountLabel() {
        return bankAccountLabel;
    }

    /**
     * Gets the player wins label.
     * @return the player wins label.
     */
    public JLabel getPlayerWinsLabel() {
        return playerWinsLabel;
    }

    /**
     * Gets the house wins label.
     * @return the house wins label.
     */
    public JLabel getHouseWinsLabel() {
        return houseWinsLabel;
    }
}
